<?php
	include "config.php";
	session_start();
	//print_r($_POST);
	$NAME=$con->real_escape_string($_POST["name"]);
	$DEPARTMENT=$con->real_escape_string($_POST["department"]);
	$FDATE=$con->real_escape_string($_POST["fdate"]);
	$TDATE=$con->real_escape_string($_POST["tdate"]);
	$LCOUNT=$con->real_escape_string($_POST["lcount"]);
	$REASON=$con->real_escape_string($_POST["reason"]);
	$OUTSTATION_REQUIRED=$con->real_escape_string($_POST["outstation_required"]);
	$ADDRESS=$con->real_escape_string($_POST["address"]);
	$PREVIOUS_LEAVE_DATES=$con->real_escape_string($_POST["previous_leave_dates"]);
	$BALANCE_DAYS=$con->real_escape_string($_POST["balance_days"]);
	
	if($BALANCE_DAYS<=12){
		$sql="insert into leave_form(NAME,DEPARTMENT,FDATE,TDATE,LCOUNT,REASON,OUTSTATION_REQUIRED,ADDRESS,PREVIOUS_LEAVE_DATES,BALANCE_DAYS,SID) values('{$NAME}','{$DEPARTMENT}','{$FDATE}','{$TDATE}','{$LCOUNT}','{$REASON}','{$OUTSTATION_REQUIRED}','{$ADDRESS}','{$PREVIOUS_LEAVE_DATES}','{$BALANCE_DAYS}','{$_SESSION["sid"]}');";
		if($con->query($sql)){
			echo 'Leave Added Success....';
		}
	
	}
?>