 <!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
      
    </style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-md-12">	
				<h3>Applied Leave Form Details</h3><hr><br>
				<?php 
			if(isset($_GET["msg"])){
				echo '<div class="alert alert-success alert-dismissible">
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  <strong>Success! </strong> '.$_GET["msg"].'
</div>';
			}
		?>
		 <table class="table table-bordered">
			<thead>
				<tr>
					<th>S.No</th>
					<th>Faculty Name</th>
					<th>Department</th>
					<th>Leave Count</th>
					<th>Reason</th>
					<th>Edit</th>
					<th>Delete</th>
					<th>View</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$sql="select * from leave_form where SID='{$_SESSION["sid"]}'";
				$res=$con->query($sql);
				$i=0;
				while($row=$res->fetch_assoc()){ $i++; ?>
				<tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $row["NAME"]; ?></td>
					<td><?php echo $row["DEPARTMENT"]; ?></td>
					<td><?php echo $row["LCOUNT"]; ?></td>
					<td><?php echo $row["REASON"]; ?></td>
					<td><a class="btn btn-sm btn-info" href="editLeave.php?lid=<?php echo $row["LID"]; ?>">Edit</a></td>
					<td><a class="btn btn-sm btn-danger" href="deleteLeave.php?lid=<?php echo $row["LID"]; ?>" onclick="return confirm('Are you sure you want to delete this Leave Form?');">Delete</a></td>
					<td><a class="btn btn-sm btn-primary" href="printLeave.php?lid=<?php echo $row["LID"]; ?>" target="_blank">View</a></td>
				</tr>
				<?php } ?>
			</tbody>
		 </table>
			</div>
        </div>
    </div>

    <?php require_once "footer.php"; ?>
</body>
</html>