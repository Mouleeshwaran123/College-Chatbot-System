<!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
		.oaddr{
			display:none;
		}
	</style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-lg-12">	
				<a href="staffAssign.php?lid=<?php echo $_GET["lid"]; ?>" class="btn btn-sm btn-danger pull-right">Back</a>
				<h3> Update Staff Assingned</h3><hr>
					
				
				<div class="col-md-12" style="margin-top:30px;">
				 <table class="table table-bordered">
					<thead>
						<tr>
							<th>S.No</th>
							<th>Faculty Name</th>
							<th>Department</th>
							<th>From Date</th>
							<th>To Date</th>
							<th>Reason</th>
							<th>Leave Count</th>
							<th>Total Count </th>
							<th>Balance Days </th>
							
						</tr>
					</thead>
					<tbody>
						<?php 
						$sql="select * from leave_form where SID='{$_SESSION["sid"]}'";
						$res=$con->query($sql);
						$i=0;
						while($row=$res->fetch_assoc()){ $i++; ?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $row["NAME"]; ?></td>
							<td><?php echo $row["DEPARTMENT"]; ?></td>
							<td><?php echo $row["FDATE"]; ?></td>
							<td><?php echo $row["TDATE"]; ?></td>
							<td><?php echo $row["REASON"]; ?></td>
							<td><?php echo $row["LCOUNT"]; ?></td>
							<td><?php echo $row["PREVIOUS_LEAVE_DATES"]; ?></td>
							<td><?php echo $row["BALANCE_DAYS"]; ?></td>
							
						</tr>
						<?php } ?>
					</tbody>
				 </table>
				
				</div>
				<div class="col-md-12">
					<?php
						if(isset($_POST["arow"])){
							$ldate=$_POST["ldate"];
							$wyear=$_POST["wyear"];
							$htype=$_POST["htype"];
							$hours=$_POST["hours"];
							$asid=$_POST["asid"];
							$sem=$_POST["sem"];
							$sql="select * from staff_assign where LID='{$_GET["lid"]}' and WYEAR='{$_POST["wyear"]}' AND HTYPE='{$_POST["htype"]}' AND HOURS='{$_POST["hours"]}' AND SEM='{$_POST["sem"]}'";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								echo "<div class='alert alert-danger'>Staff Already Assigned... </div>";
							}else{
								$sql="INSERT INTO staff_assign(SID, LDATE, WYEAR, HTYPE, HOURS, ASID,LID,SEM) VALUES ('{$_SESSION["sid"]}','{$ldate}','{$wyear}','{$htype}','{$hours}','{$asid}','{$_GET["lid"]}','{$sem}')";
								if($con->query($sql)){
									echo "<div class='alert alert-success'>Staff Assigned success</div>";
								}else{
									echo "<div class='alert alert-danger'>Staff Assigned Failed</div>";
								}
							}
						}
						$sql="select * from leave_form where LID='{$_GET["lid"]}'";
						$res=$con->query($sql);
						if($res->num_rows>0)
						{
							$re=$res->fetch_assoc();
							
						}
						
						$sql="select staff_details.FNAME,staff_assign.* from staff_assign inner join staff_details on staff_assign.ASID=staff_details.SID where staff_assign.SAID='{$_GET["said"]}'";
						$res=$con->query($sql);
						if($res->num_rows>0)
						{
							$row=$res->fetch_assoc();
							
						}
					?>
					<form action="<?php echo $_SERVER["REQUEST_URI"];?>" method="post" >
						<div class="form-group col-md-3">
							<label>Date</label>
							<select class="form-control" name="ldate" >
								<?php
									$fdate=$re["FDATE"];
									$tdate=$re["TDATE"];
									$start_date = new DateTime($fdate);
									$end_date = new DateTime($tdate);
									while($end_date >= $start_date)
									{
									   $d= $start_date->format('Y-m-d');
									   echo'
											<option value="'.$d.'">'.$d.'</option>
									   ';
									   $start_date->add(new DateInterval('P1D'));
									}
								?>
							</select>
								
						</div>
						<div class="form-group col-md-9">
							<label>Work Assigned</label><br>
							<div class="col-md-3">
								<select class="form-control" name="wyear">
									<option value="<?php echo $row["WYEAR"]; ?>"> <?php echo $row["WYEAR"]; ?></option>
									<option Value="I">I</option>
									<option Value="II">II</option>
									<option Value="III">III</option>
									<option Value="IV">IV</option>
								</select>
							</div>
							<div class="col-md-3">
								<select class="form-control" name="sem">
									<option value="<?php echo $row["SEM"]; ?>"> <?php echo $row["SEM"]; ?></option>
									<option Value="I">I</option>
									<option Value="II">II</option>
									<option Value="III">III</option>
									<option Value="IV">IV</option>
									<option Value="V">V</option>
									<option Value="VI">VI</option>
								</select>
							</div>
							<div class="col-md-3">
								<select class="form-control" name="htype">
									<option value="<?php echo $row["HTYPE"]; ?>"> <?php echo $row["HTYPE"]; ?></option>
									<option Value="Theory">Theory</option>
									<option Value="Lab">Lab</option>
								</select>
							</div>
							<div class="col-md-3">
								<select class="form-control" name="hours">
									<option value="<?php echo $row["HOURS"]; ?>"> <?php echo $row["HOURS"]; ?></option>
									<option Value="1">1</option>
									<option Value="2">2</option>
									<option Value="3">3</option>
									<option Value="4">4</option>
									<option Value="5">5</option>
									<option Value="6">6</option>
									<option Value="7">7</option>
								</select>
							</div>
							
						</div>
						<div class="form-group col-md-6">
							<label>Faculty Name</label>
							<select class="form-control" name="asid">
								<option value="<?php echo $row["SID"]; ?>"> <?php echo $row["FNAME"]; ?></option>
								<?php
									$sql="select * from staff_details where SID!='{$_SESSION["sid"]}'";
									$res=$con->query($sql);
									if($res->num_rows>0)
									{
										while($ro=$res->fetch_assoc())
										{
											echo'
												<option value="'.$ro["SID"].'">'.$ro["FNAME"].'</option>
											';
										}
										
									}
								
								?>
							</select>
						</div>
						<div class="col-md-12">
							<button type="submit" name="arow" class="btn btn-success">Update Rows</button>
						</div>
					</form>
				</div>
				
			
			</div>	
		</div>
    </div>

    <?php require_once "footer.php"; ?>

</body>
</html>