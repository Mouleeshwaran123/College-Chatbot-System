<!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
      
    </style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-lg-12">			
				<div class="col-md-offset-3 col-md-6">
					<div class="panel panel-primary">
						<div class="panel panel-heading">
							Faculty Login
						</div>
						<div class="panel panel-body">
							<div class="col-md-12">
								<?php
									if(isset($_POST["submit"]))
									{
										$staffid = $con->real_escape_string($_POST["staffid"]);
										$spass = $con->real_escape_string($_POST["spass"]);

										$sql="select * from staff_details where STAFFID='{$staffid}' and SPASS='{$spass}'";
										$res=$con->query($sql);
										if($res->num_rows>0)
										{
											$ro=$res->fetch_assoc();
											$_SESSION["sid"]=$ro["SID"];
											$_SESSION["staffid"]=$ro["STAFFID"];
											$_SESSION["fname"]=$ro["FNAME"];
											$_SESSION["depart"]=$ro["DEPART"];
										echo "<script>window.open('staff_home.php','_self');</script>";

										}else{
											echo "<div class='alert alert-danger'>Invalid username or password</div>";
										}
									}

								?>
								<form action="<?php echo $_SERVER["REQUEST_URI"];?>" method="post" autocomplete="off">
									<div class=" from-group">
										<label for=""> Faculty ID </label>
										<input type="text" name="staffid" class="form-control">
									</div>
									<div class="from-group">
										<label for="">Faculty Password</label>
										<input type="password" class="form-control" name="spass">
									</div>
									<br>
										
									<div class="from-group">
										<button type="submit" class="btn btn-success " name="submit"> Login</button>
									</div><br>
									
										<a href="staff_register.php" class="text-primary text-rigth">New Registeration...?</a>
									
								</form>
							</div>
						</div>
					</div>
				</div>
				
			</div>
        </div>
    </div>

    <?php require_once "footer.php"; ?>
</body>
</html>