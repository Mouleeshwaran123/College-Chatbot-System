			<p class="smalltamil">வகுப்புகள் மாற்று ஏற்பாடு குறித்த விவரம்:</p>
  	
	 <table class="table table-bordered table-tamil" id="mytable">
    <thead>
      <tr>
        <th>விடுப்பு நாள்</th>
        <th>மாற்று ஏற்பாடு செய்துள்ள <br>  வகுப்ப  இதரப்பணி</th>
        <th>வகுப்பு   இதரப்பணி நடத்த  <br> ஓப்பக்கொண்டவர் பெயர்</th>
      </tr>
    </thead>
	<tbody>
				
	</tbody>
	<tfoot>
        <tr>
          <td colspan='3'><input type='button' value='+Add Row' id='add_row'></td>
        </tr>
      </tfoot>
	</table>