<!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
      
    </style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-md-12">	
				<a href="index.php" class="btn btn-sm btn-danger pull-right">Back</a>
				<h3>Welcome Admin</h3><hr>	
					
				
				
			</div>
        </div>
    </div>

    <?php require_once "footer.php"; ?>
</body>
</html>