<?php
	$date1=date_create($_POST["start"]);
	$date2=date_create($_POST["end"]);
	$diff=date_diff($date1,$date2);
	$check= $diff->format("%a");


    $fdate=$_POST["start"];
    $fdate=strtotime($fdate);
    $tdate=$_POST["end"];
	$tdate=strtotime($tdate);
	
	
	$temp_bdays=$_POST["temp_bdays"];
	$dif=abs($temp_bdays-$check);
?>
	<?php if(($dif>=0 && $dif<=12)&&$check<=12){ ?>
    <table class='table table-bordered' id="tblDate">
    <thead>
        <th>Date</th>
        <th>Holiday</th>
    </thead>
    <tbody>
    <?php
        $tot=0;
        for($i=$fdate;$i<=$tdate;$i+=86400)
        {
           
            echo "
                <tr>
                    <td>".date('d-m-Y',$i)."</td>
                    <td><input type='checkbox' style='margin:10px;' name='ccount' class='ctot'></td>
                </tr>";
            $tot++;
        } 	
    ?>
    </tbody>
    </table>
    <input type="hidden" id="rtot" value="<?php echo $tot;?>">
	<?php }else{ 
		echo "<b style='color:red;'>Please Check your leave Dates..</b>";
		
	} ?>
    <script src="js/jquery.min.js"></script>
   