

<script src="js/jquery.min.js"></script>
<script src="js/main.js"></script>
<script src="jquery-ui/jquery-ui.min.js"></script>

<script>
	$(document).ready(function(){

		$(".alert").fadeTo(1000, 100).slideUp(1000, function(){
				$(".alert").slideUp(1000);
			});

	});
</script>


