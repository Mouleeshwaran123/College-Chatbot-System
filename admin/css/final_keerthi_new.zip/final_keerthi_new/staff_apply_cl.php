<!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
		.oaddr{
			display:none;
		}
	</style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-lg-12">	
				<a href="staff_home.php" class="btn btn-sm btn-danger pull-right">Back</a>
				<h6 class="tamil">அனுமதி / தற்செயல் விடுப்பு விண்ணப்பம் </h6><hr>
					<?php
			
						 $sql="select LCOUNT from leave_form where SID='{$_SESSION["sid"]}'";
							$res=$con->query($sql);
							$ltotal=0;
							$bcount=12;
							if($res->num_rows>0){
								
								while($row=$res->fetch_assoc()){
									$lcount=$row["LCOUNT"];
									$ltotal+=$lcount;
								}
								$bcount=12-$ltotal;	
								
							}else{
								$ltotal=0;
							}
						
					?>
				<div class="col-md-8">
					<form id="frm" method="post" autocomplete="off">
					
						<div class=" from-group">
							<label class="smalltamil">பெயர் : </label>
							<input type="text" class="form-control form-control-sm text" id="name" placeholder="Enter Name" name="name"  value="<?php echo $_SESSION["fname"];?>" readonly>
						</div><br style="clear:both;">
						<div class="from-group">
							<label class="smalltamil">பிரிவு : </label>
							<input type="text" class="form-control form-control-sm text" id="department" placeholder="Enter department" name="department"  value="<?php echo $_SESSION["depart"];?>" readonly>
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="fdate" class="form-label smalltamil">அனுமதி / விடுப்பு வேண்டிய தொடக்க நாட்கள் : </label>
							<input type="text" class="form-control datepicker" id="fdate" placeholder="Select Date" name="fdate" >
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="tdate" class="form-label smalltamil">அனுமதி / விடுப்பு வேண்டிய முடிவு நாட்கள் : </label>
							<input type="text" class="form-control datepicker" id="tdate" placeholder="Select Date" name="tdate" >
						</div><br style="clear:both;">
						 

					  <div id="out">
								
					  </div><br style="clear:both;">
					  <div class="out2">
						 
					  </div>
						<div class="from-group">
							<label for="lcount" class="form-label smalltamil">மொத்த விடுப்பு வேண்டிய நாட்கள் : </label>
							<input type="text" class="form-control form-control-sm" id="lcount" name="lcount" value="0">
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="reason" class="form-label smalltamil">அனுமதிக்கான / விடுப்புக்கான காரணம் : </label>
							<textarea class="form-control form-control-sm" rows="3" id="reason"  name="reason" placeholder="Enter Leave Reason" style="resize:none;" ></textarea>
						</div><br style="clear:both;">
					
						<div class=" from-group">
							<label for="outstation_required" class="form-label smalltamil">வெளியுர் செல்ல அனுமதிகள் : </label>
						<select class="form-control form-control-sm" id="outstation" name="outstation_required" >
							<option value="">Select Option</option>
							<option value="No">No</option>
							<option value="Yes">Yes</option>
						</select>
						</div><br style="clear:both;">
						<div class="from-group oaddr" id="address">
							<label for="address" class="form-label smalltamil">வெளியுர் முகவரி : </label>
							<input type="text" class="form-control form-control-sm" id="address" placeholder="Enter Address" name="address" >
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="previous_leave_dates" class="form-label smalltamil">இதுவரை எடுத்த விடுப்பு நாட்கள்  : ( தற்போதைய விடுப்புடன் சேர்த்து )</label>
							<input type="text" class="form-control form-control-sm" id="previous_leave_dates" placeholder="Previous Leave Days" name="previous_leave_dates"  value="<?php echo $ltotal;?>">
							<input type="hidden" class="form-control form-control-sm" id="previous_leave_dates1" placeholder="Previous Leave Days" name="previous_leave_dates1"  value="<?php echo $ltotal;?>">
						</div><br style="clear:both;">
						<div class="from-group">
						<label for="balance_days" class="form-label smalltamil">மீதியுள்ள நாட்கள்</label>
						<input type="text" class="form-control form-control-sm" id="balance_days" placeholder="Enter Balance Days" name="balance_days" value="<?php echo $bcount;?>" >
						<input type="hidden" class="form-control form-control-sm" id="balance_days1" placeholder="Enter Balance Days" name="balance_days1" value="<?php echo $bcount;?>" >
						</div><br style="clear:both;">
				
				
						<div class="from-group"><br>
							<button type="button" class="btn btn-success " id="btnSubmit" name="submit"> Apply Leave</button>
						</div>						
								
					</form>
				</div>
				
				<div class="col-md-12" style="margin-top:30px;">
				 <table class="table table-bordered">
					<thead>
						<tr>
							<th>S.No</th>
							<th>Faculty Name</th>
							<th>Department</th>
							<th>From Date</th>
							<th>To Date</th>
							<th>Reason</th>
							<th>Leave Count</th>
							<th>Total Count </th>
							<th>Balance Days </th>
							
							<th>Assign</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$sql="select * from leave_form where SID='{$_SESSION["sid"]}'";
						$res=$con->query($sql);
						$i=0;
						while($row=$res->fetch_assoc()){ $i++; 
							$bdays=12-$row["PREVIOUS_LEAVE_DATES"];
						?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $row["NAME"]; ?></td>
							<td><?php echo $row["DEPARTMENT"]; ?></td>
							<td><?php echo $row["FDATE"]; ?></td>
							<td><?php echo $row["TDATE"]; ?></td>
							<td><?php echo $row["REASON"]; ?></td>
							<td><?php echo $row["LCOUNT"]; ?></td>
							<td><?php echo $row["PREVIOUS_LEAVE_DATES"]; ?></td>
							<td><?php echo $bdays; ?></td>
							<td><a class="btn btn-sm btn-info" href="staffAssign.php?lid=<?php echo $row["LID"]; ?>">Assign</a></td>
						</tr>
						<?php } ?>
					</tbody>
				 </table>
				
				</div>
			</div>	
		</div>
    </div>

    <?php require_once "footer.php"; ?>
	<script>
	$(document).ready(function(){
		//Date picker
		$( ".datepicker" ).datepicker({
			dateFormat: 'yy-mm-dd',
			changeMonth: true,
			changeYear: true,
			yearRange: '1900:2150',
			minDate:0
			
		});
		
		//set current date
		$('#fdate').datepicker('setDate', 'today');

      	//Disable previous date
		$('#fdate').datepicker(
			{
				dateFormat: 'yy-mm-dd',
				changeMonth: true,
				changeYear: true,
				yearRange: '1900:2150',
				
			}
		);

	//Address change
	$("#outstation").change(function(){
		var out=$(this).val();
		if(out=='Yes'){
			$("#address").removeClass("oaddr");
		}else{
			$("#address").addClass("oaddr");
		}
	});

	// fromDate to ToDate print
	$("#fdate, #tdate").change(function(){
		var fdate = $("#fdate").val();
		var tdate = $("#tdate").val();
		
		var pleaveCount=parseInt($("#previous_leave_dates").val());
		var bdays=parseInt($("#balance_days").val());
		
		var temp_pleaveCount=parseInt($("#previous_leave_dates1").val());
		var temp_bdays=parseInt($("#balance_days1").val());
		//alert(temp_bdays);
		//alert(pleaveCount);
			$.ajax({
				type:'POST',
				url:'printDates.php',
				data:{start:fdate,end:tdate,temp_bdays:temp_bdays},
				success:function(data){
					//alert(data);
					$("#out").html(data);
					$("#lcount").val(getCount());
					
					var prev= parseInt($("#previous_leave_dates1").val());
					var tot=prev+parseInt($("#lcount").val());
					$("#previous_leave_dates").val(tot);
					getBcount();
					
				}
			});
			
			getPleaveCount();
			
	});

	//remove count
	
	function getCount(){
		var count=0;
		$('#tblDate tbody tr').each(function() {
			if ($(this).find('.ctot').is(':not(:checked)')){
				count++;
			}
		});  
		return(count);
	}
	//Total Leave Days
	
	function getPleaveCount(){
			var lcount= parseInt(getCount());
			var prev= parseInt($("#previous_leave_dates1").val());
			var total=lcount+prev;
			console.log(lcount,prev,total);
			$("#previous_leave_dates").val(total);
		}

	function getBcount(){
		var lcount= parseInt(getCount());
		
		var bday= parseInt($("#balance_days1").val());
		bd=bday-lcount;
		console.log(lcount);
		if(bd<0)
		{
			$("#balance_days").val(12);
		}else{
			$("#balance_days").val(bd);
		}
		
	}
	
	$(document).on('change','.ctot' ,function(){
		var pleaveCount=parseInt($("#previous_leave_dates").val());
		var bdays=parseInt($("#balance_days").val());
		var lcount= parseInt($("#lcount").val(getCount()));
		getPleaveCount();
		getBcount();
		
		
		
	});
	
	

	
	//get table value
	function getTableVal(){
	var tldate=[];
		$('#mytable tbody tr').each(function() {
			tldate=$(this).find('.tldate').val();
			
		});
		return(tldate);
	}
	$(document).on('click','#btnSubmit',function(){	
		
		$.ajax({
			url: 'saveForm.php',
			method: 'post',
			data: $("#frm").serialize(),
			success: function(data){
				alert(data);
				location.reload();
			}   
		});
	});


});

</script>
</body>
</html>