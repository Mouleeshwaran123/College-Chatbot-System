<?php 
	$con =new mysqli("localhost","root","","leave_management");
?>