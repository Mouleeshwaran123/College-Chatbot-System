<!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
      
    </style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br><br>
        <div class="row">
			<div class="col-lg-12">			
				<div class="col-md-offset-2 col-lg-3">			
					<div class="panel panel-primary">
     						<div class="panel-heading">
								Admin
							</div>
							<div class="panel-body">
								<center>
									<a href="admin.php"> <i  class="fa fa-user fa-5x" >  </i></a>
								</center>	
							</div>
					</div>				
				</div>
				<div class="col-md-offset-2 col-lg-3">			
					<div class="panel panel-primary">
     						<div class="panel-heading">
								Faculty
							</div>
							<div class="panel-body">
								<center>
									<a href="staff_login.php"> <i  class="fa fa-users fa-5x" >  </i></a>
								</center>	
							</div>
					</div>				
				</div>
				<!--<div class="col-md-offset-1 col-lg-3">			
					<div class="panel panel-primary">
     						<div class="panel-heading">
								Student
							</div>
							<div class="panel-body">
								<center>
									<a href="student_login.php"> <i  class="fa fa-user fa-5x" >  </i></a>
								</center>	
							</div>
					</div>				
				</div>-->
				
			</div>
        </div>
    </div>

    <?php require_once "footer.php"; ?>
</body>
</html>