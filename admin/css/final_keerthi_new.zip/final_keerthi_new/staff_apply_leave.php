<!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
		.oaddr{
			display:none;
		}
	</style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-lg-12">	
				<a href="staff_home.php" class="btn btn-sm btn-danger pull-right">Back</a>
				<h6 class="tamil">அனுமதி / தற்செயல் விடுப்பு விண்ணப்பம் </h6><hr>
					
			<div class="col-md-7">
					<form id="frm" method="post" >
							<?php
                    if(isset($_POST["submit"]))  {
                        $name=$con->real_escape_string($_POST["name"]);
                        $design=$con->real_escape_string($_POST["design"]);
                        $depart=$con->real_escape_string($_POST["depart"]);
                        $lnature=$con->real_escape_string($_POST["lnature"]);
                        $reason=$con->real_escape_string($_POST["reason"]);
                        $ldays=$con->real_escape_string($_POST["ldays"]);
                        $laddress=$con->real_escape_string($_POST["laddress"]);
                        $notes=$con->real_escape_string($_POST["notes"]);
                        $place=$con->real_escape_string($_POST["place"]);
                        $sdate=$con->real_escape_string($_POST["sdate"]);
                    

                        $sql="insert into spem_leave(NAME, DESIGN, DEPART, LNATURE, REASON, LDAYS, LADDRESS, NOTES, PLACE, SDATE,CTYPE) VALUES('{$name}','{$design}','{$depart}','{$lnature}','{$reason}','{$ldays}','{$laddress}','{$notes}','{$place}','{$sdate}','{$_GET["ctype"]}')";
                        if($con->query($sql))
                        {
                            echo '<div class="alert alert-success alert-dismissible">
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        <strong>Success!</strong> Leave Added Success.
                        </div>';
                        }else{
                            echo '<div class="alert alert-danger alert-dismissible">
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        <strong>Failed!</strong> Leave Added Failed.
                        </div>';
                        }
                    }  
                ?>
						<div class=" from-group">
							<label class="smalltamil">பெயர் : </label>
							<input type="text" class="form-control form-control-sm text" id="name" placeholder="Enter Name" name="name"  value="<?php echo $_SESSION["fname"];?>" readonly>
						</div><br style="clear:both;">
						<div class="from-group">
							<label class="smalltamil">பதவி  : </label>
							<input type="text" class="form-control form-control-sm text" id="design" placeholder="Enter Designation" name="design">
						</div><br style="clear:both;">
						<div class="from-group">
							<label class="smalltamil">பிரிவு : </label>
							<input type="text" class="form-control form-control-sm text" id="department" placeholder="Enter department" name="department"  value="<?php echo $_SESSION["depart"];?>" readonly>
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="lnature" class="form-label smalltamil">தேவைபடும் விடுப்பின் தன்மை : </label>
							<input type="text" class="form-control " id="lnature" placeholder="Enter Leave Nature" name="lnature" >
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="reason" class="form-label smalltamil">விடுப்பு வேண்டுவதற்கான காரணம் (தேவைப்படின் மருத்துவச் சான்று இணைக்கவும்) :</label>
							<input type="text" class="form-control" id="reason" placeholder="Enter Reason" name="reason" >
						</div><br style="clear:both;">	
						<div class="from-group">
							<label for="ldays" class="form-label smalltamil">விடுப்பு கால அளவு (அரசு விடுமுறை நாட்கள் விடுப்புடன் முன் / பின் இணைத்து பயன்படுத்துவதாயின் அதன் விவரம்) : </label>
							<input type="text" class="form-control form-control-sm" id="ldays" placeholder="Enter Leave Days" name="ldays">
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="laddress" class="form-label smalltamil">விடுப்பு முகவரி :</label>
							<textarea class="form-control form-control-sm" rows="3" id="laddress"  name="laddress" placeholder="Enter Leave Address" style="resize:none;" ></textarea>
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="place" class="form-label smalltamil">இடம் :</label>
							<input type="text" class="form-control" id="place" placeholder="Select Date" name="place" >
						</div><br style="clear:both;">
						<div class="from-group">
							<label for="sdate" class="form-label smalltamil">நாள் :</label>
							<input type="text" class="form-control datepicker" id="sdate" placeholder="Select Date" name="sdate" >
						</div><br style="clear:both;">
				
						<div class="from-group"><br>
							<button type="button" class="btn btn-success " id="btnSubmit" name="submit"> Apply Leave</button>
						</div>						
								
					</form>
				</div>
				</div>
				
			</div>
        </div>
    </div>

    <?php require_once "footer.php"; ?>
	<script>
	$(document).ready(function(){
		//Date picker
		$( ".datepicker" ).datepicker({
			dateFormat: 'yy-mm-dd',
			changeMonth: true,
			changeYear: true,
			yearRange: '1900:2150',
			minDate:0
			
		});
		
		//set current date
		$('#fdate').datepicker('setDate', 'today');

      	//Disable previous date
		$('#fdate').datepicker(
			{
				dateFormat: 'yy-mm-dd',
				changeMonth: true,
				changeYear: true,
				yearRange: '1900:2150',
				
			}
		);


</script>
</body>
</html>