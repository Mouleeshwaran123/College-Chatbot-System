<?php 
include "config.php"; 
$sql="delete from staff_assign where SAID='{$_GET["said"]}'";
$con->query($sql);
echo "<script>location.replace('staffAssign.php?lid={$_GET["lid"]}');</script>"; 
?>