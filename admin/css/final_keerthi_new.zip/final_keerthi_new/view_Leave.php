 <!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
      
    </style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-md-12">	
			<!--	<a href="index.php" class="btn btn-sm btn-danger pull-right">Back</a> -->
				<h3>View Leave Type</h3><hr>	
					
					<div class="col-md-4">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="text-center"><a href="staff_view_cl.php" class="text-white txt">VIEW CL</a></h3>
							</div>
						</div>	
					</div>
					<div class="col-md-4">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="text-center"><a href="staff_view_leave.php?ctype=1" class="text-white txt">VIEW SPCL</a></h3>
							</div>
						</div>	
					</div>
					<div class="col-md-4">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="text-center"><a href="staff_apply_ol.php" class="text-white txt">VIEW OD</a></h3>
							</div>
						</div>	
					</div>
					<div class="col-md-4">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="text-center"><a href="staff_view_leave.php?ctype=2" class="text-white txt">VIEW EL</a></h3>
							</div>
						</div>	
					</div>
					<div class="col-md-4">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="text-center"><a href="staff_view_leave.php?ctype=3" class="text-white txt">VIEW ML</a></h3>
							</div>
						</div>	
					</div>
					<div class="col-md-4">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="text-center"><a href="staff_apply_od1.php" class="text-white txt">VIEW OD</a></h3>
							</div>
						</div>	
					</div>
				
				</div>
				
			</div>
        </div>
    </div>

    <?php require_once "footer.php"; ?>
</body>
</html>