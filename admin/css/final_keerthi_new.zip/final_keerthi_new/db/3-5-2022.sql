-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.17-MariaDB


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema leave_management
--

CREATE DATABASE IF NOT EXISTS leave_management;
USE leave_management;

--
-- Definition of table `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `CID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CNAME` varchar(150) NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` (`CID`,`CNAME`) VALUES 
 (1,'CSE'),
 (2,'GEO'),
 (3,'MECH'),
 (4,'ECE'),
 (5,'MBA'),
 (6,'MCA');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;


--
-- Definition of table `designation`
--

DROP TABLE IF EXISTS `designation`;
CREATE TABLE `designation` (
  `DESID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DESNAME` varchar(150) NOT NULL,
  PRIMARY KEY (`DESID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `designation`
--

/*!40000 ALTER TABLE `designation` DISABLE KEYS */;
INSERT INTO `designation` (`DESID`,`DESNAME`) VALUES 
 (1,'HOD'),
 (2,'Professor'),
 (3,'Assistant Professor'),
 (4,'Associate Professor'),
 (5,'Library Assistant'),
 (6,'Attender'),
 (7,'Office Assistant'),
 (8,'Computer Operator');
/*!40000 ALTER TABLE `designation` ENABLE KEYS */;


--
-- Definition of table `leave_form`
--

DROP TABLE IF EXISTS `leave_form`;
CREATE TABLE `leave_form` (
  `LID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(150) DEFAULT NULL,
  `DEPARTMENT` varchar(150) DEFAULT NULL,
  `FDATE` date DEFAULT NULL,
  `REASON` varchar(150) DEFAULT NULL,
  `OUTSTATION_REQUIRED` varchar(150) DEFAULT NULL,
  `ADDRESS` text DEFAULT NULL,
  `PREVIOUS_LEAVE_DATES` varchar(150) DEFAULT NULL,
  `BALANCE_DAYS` varchar(150) DEFAULT NULL,
  `TDATE` date DEFAULT NULL,
  `LCOUNT` varchar(150) DEFAULT NULL,
  `SID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`LID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leave_form`
--

/*!40000 ALTER TABLE `leave_form` DISABLE KEYS */;
INSERT INTO `leave_form` (`LID`,`NAME`,`DEPARTMENT`,`FDATE`,`REASON`,`OUTSTATION_REQUIRED`,`ADDRESS`,`PREVIOUS_LEAVE_DATES`,`BALANCE_DAYS`,`TDATE`,`LCOUNT`,`SID`) VALUES 
 (1,'Sandhiya','CSE','2022-05-03','','','','4','8','2022-05-06','4',3),
 (2,'Sandhiya','CSE','2022-05-03','test2','Yes','test-1','5','7','2022-05-05','1',3);
/*!40000 ALTER TABLE `leave_form` ENABLE KEYS */;


--
-- Definition of table `spem_leave`
--

DROP TABLE IF EXISTS `spem_leave`;
CREATE TABLE `spem_leave` (
  `SLID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(150) NOT NULL,
  `DESIGN` varchar(150) NOT NULL,
  `DEPART` varchar(150) NOT NULL,
  `LNATURE` varchar(150) NOT NULL,
  `REASON` varchar(150) NOT NULL,
  `LDAYS` varchar(150) NOT NULL,
  `LADDRESS` varchar(150) NOT NULL,
  `NOTES` varchar(150) NOT NULL,
  `PLACE` varchar(150) NOT NULL,
  `SDATE` date NOT NULL,
  `CTYPE` varchar(150) NOT NULL,
  PRIMARY KEY (`SLID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `spem_leave`
--

/*!40000 ALTER TABLE `spem_leave` DISABLE KEYS */;
INSERT INTO `spem_leave` (`SLID`,`NAME`,`DESIGN`,`DEPART`,`LNATURE`,`REASON`,`LDAYS`,`LADDRESS`,`NOTES`,`PLACE`,`SDATE`,`CTYPE`) VALUES 
 (1,'Ram','Staff','BBA','Test','test','test','test','Test','salem','2022-04-05','1'),
 (2,'TARA','dfsdf','BBA','fsdf','we','sdfs','sfs','dfsd','sfd','2022-04-05','2');
/*!40000 ALTER TABLE `spem_leave` ENABLE KEYS */;


--
-- Definition of table `staff_assign`
--

DROP TABLE IF EXISTS `staff_assign`;
CREATE TABLE `staff_assign` (
  `SAID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SID` int(10) unsigned NOT NULL,
  `LDATE` date NOT NULL,
  `WYEAR` varchar(45) NOT NULL,
  `HTYPE` varchar(45) NOT NULL,
  `HOURS` varchar(45) NOT NULL,
  `ASID` int(10) unsigned NOT NULL,
  `LID` int(10) unsigned NOT NULL,
  `SEM` varchar(45) NOT NULL,
  PRIMARY KEY (`SAID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_assign`
--

/*!40000 ALTER TABLE `staff_assign` DISABLE KEYS */;
INSERT INTO `staff_assign` (`SAID`,`SID`,`LDATE`,`WYEAR`,`HTYPE`,`HOURS`,`ASID`,`LID`,`SEM`) VALUES 
 (1,1,'2022-04-27','I','Theory','1',2,1,'I'),
 (2,1,'2022-04-27','I','Lab','2',2,1,'I'),
 (3,1,'2022-04-27','I','Theory','3',2,1,'I');
/*!40000 ALTER TABLE `staff_assign` ENABLE KEYS */;


--
-- Definition of table `staff_details`
--

DROP TABLE IF EXISTS `staff_details`;
CREATE TABLE `staff_details` (
  `SID` int(11) NOT NULL AUTO_INCREMENT,
  `FNAME` varchar(150) DEFAULT NULL,
  `MNAME` varchar(150) DEFAULT NULL,
  `LNAME` varchar(150) DEFAULT NULL,
  `STAFFID` varchar(150) DEFAULT NULL,
  `SPASS` varchar(150) DEFAULT NULL,
  `DESTI` varchar(150) DEFAULT NULL,
  `DEPART` varchar(150) DEFAULT NULL,
  `GENDER` varchar(150) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `CONTACT` varchar(150) DEFAULT NULL,
  `ADDRESS` varchar(150) DEFAULT NULL,
  `EMAIL` varchar(150) NOT NULL,
  PRIMARY KEY (`SID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_details`
--

/*!40000 ALTER TABLE `staff_details` DISABLE KEYS */;
INSERT INTO `staff_details` (`SID`,`FNAME`,`MNAME`,`LNAME`,`STAFFID`,`SPASS`,`DESTI`,`DEPART`,`GENDER`,`DOB`,`CONTACT`,`ADDRESS`,`EMAIL`) VALUES 
 (1,'Pooja','-','Kumar','101','123','Assistant Professor','MCA','Female','1990-10-02','23424354565','3434 - Anna Nagar','pooja@gmail.com'),
 (2,'Sam',NULL,NULL,'102','1234','Professor','CSE','Female','1986-05-31','7896541203','salem','sam@gmail.com'),
 (3,'Sandhiya',NULL,NULL,'105','1234','Professor','CSE','Female','1999-05-03','9632014587','salem','sandhiya@gmail.com');
/*!40000 ALTER TABLE `staff_details` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
