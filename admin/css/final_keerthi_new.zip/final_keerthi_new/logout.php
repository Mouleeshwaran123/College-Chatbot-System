
<?php 
session_start();
session_destroy();
unset($_SESSION["sid"]);
unset($_SESSION["staffid"]);
unset($_SESSION["fname"]);
unset($_SESSION["aid"]);
unset($_SESSION["aname"]);
echo "<script>window.open('index.php','_self')</script>";

?>