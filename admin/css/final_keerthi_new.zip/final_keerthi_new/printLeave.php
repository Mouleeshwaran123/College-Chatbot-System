<?php

    require_once 'fpdf/fpdf.php';
    require_once 'config.php';
	session_start();
    //A4 -- size--- mm --- 210 * 297
    //A5 -- size--- mm --- 210 * 148
	
	
	
   //A4 Size mm 209 * 297--10
    //margin(left and right)(20)219-20-189
    //new FPDF("orientation","measurement","paper")
    $pdf = new FPDF('P','mm','A4');

    $pdf ->AddPage();
	//Image(location,x axis,y axis,width,height,format)
	$pdf ->Image('images/logo.png',17,10,20,20, 'PNG');
    //add font ('font name','style','phpfile')
    $pdf ->addFont('Roboto','B','Roboto.php');
    $pdf ->addFont('Roboto','','Roboto.php');
    $pdf ->addFont('RobotoCondensed','','RobotoCondensed.php');
    $pdf ->addFont('RobotoCondensedb','','RobotoCondensedb.php');
    $pdf ->addFont('RobotoBlack','','RobotoBlack.php');
    $pdf ->addFont('Baamini','','Baamini.php');
    //set font to arial,bold,14px
    $pdf ->SetFont('Baamini','',15);   
    //cell(width,height,text,border,end line, [align])
    $pdf ->Cell(200,10,'mz;zh gy;fiyf;fofk; kz;ly tshfk; - jpUney;Ntyp;',0,1,'C');
    $pdf ->Cell(200,6,'jpUney;Ntyp - 627 007',0,1,'C');
    $pdf ->Cell(189,10,'','B',1);//end
    $pdf ->Cell(189,5,'',0,1);//end
    $pdf ->Cell(5,5,'',0,0);
    $pdf ->SetFont('Baamini','',14);   
    $pdf ->Cell(179,7,'mDkjp - jw;nray; tpLg;G tpz;zg;gk; ',0,1,'C');
    $pdf ->Cell(10,10,'',0,1);//end
	
	$sql="select leave_form.*,staff_details.* from leave_form inner join staff_details on leave_form.SID=staff_details.SID where  leave_form.LID={$_GET["lid"]} and	leave_form.SID={$_SESSION["sid"]}";
	$_GLOBAL["ro"]=Array();
	$res=$con->query($sql);
	if($res->num_rows>0)
	{
		$_GLOBAL["ro"]=$res->fetch_assoc();
		$lcount=$_GLOBAL["ro"]['LCOUNT'];
		$bdays=12-$_GLOBAL["ro"]['PREVIOUS_LEAVE_DATES'];
		
		
	
	
    $pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'1. ngah;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$_GLOBAL["ro"]['FNAME'],'B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'2. gpupT',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$_GLOBAL["ro"]['DEPARTMENT'],'B',1);

	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'3. mDkjp - tpLg;G Ntz;ba ehl;fs;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$lcount,'B',1);

    $pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'4. mDkjpf;fhd - tpLg;Gf;fhd fhuzk;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$_GLOBAL["ro"]['REASON'],'B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'5. ntspAh; nry;y mDkjp ',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$_GLOBAL["ro"]['OUTSTATION_REQUIRED'],'B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'6. ntspAh; Kfthp',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$_GLOBAL["ro"]['ADDRESS'],'B',1);

	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'7. ,Jtiu vLj;j tpLg;G ehl;fs;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$_GLOBAL["ro"]['PREVIOUS_LEAVE_DATES'],'B',1);
    $pdf ->Cell(10,5,'',0,0); 
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(80,5,'(jw;Nghija tpLg;Gld; Nrh;j;J)',0,1);
   
   
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'8. kPjpAs;s ehl;fs;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,$_GLOBAL["ro"]['BALANCE_DAYS'],'B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(50,2,' ',0,1); 
    $pdf ->Cell(50,5,'Njjp: ',0,1); 

    $pdf ->Cell(50,2,' ',0,1); 
    $pdf ->Cell(135,5,'',0,0); 
    $pdf ->Cell(40,5,'tpz;zg;gjhuh; ifnahg;gk;',0,1); 

    $pdf ->Cell(50,2,' ',0,1); 
    $pdf ->Cell(135,5,'tFg;Gfs; khw;W Vw;ghL Fwpj;j tptuk;:    ',0,1); 
	$pdf ->SetFont('Baamini','',8); 
    $pdf ->Cell(50,2,' ',0,1);
    $x_axis=$pdf->getx();
    $pdf ->vcell(20,10,$x_axis,'thpirvz;',5,0);
    $pdf ->Cell(40,10,'tpLg;G ehs;',1,0,'C'); 
    $x_axis=$pdf->getx();
    $pdf ->vcell(40,10,$x_axis,'  khw;W Vw;ghL nra;Js;s   tFg;G ,jug;gzp',25,0);
    $x_axis=$pdf->getx();
    $pdf ->vcell(47,10,$x_axis,'   tFg;G-,jug;gzp elj;j    Xg;gf;nfhz;lth; ngah;',25,0);
    $x_axis=$pdf->getx();
    $pdf ->vcell(40,10,$x_axis,'Xg;gf;nfhz;lth; ifnahg;gk;',15,1);
	$pdf ->SetFont('RobotoCondensed','',8);
	$sql="select staff_details.FNAME,staff_assign.* from staff_assign inner join staff_details on staff_assign.ASID=staff_details.SID where staff_assign.LID={$_GET["lid"]} and staff_assign.SID={$_SESSION["sid"]}	";
	$_GLOBAL["ro1"]=Array();
	$res=$con->query($sql);
	if($res->num_rows>0)
	{
		$i=0;
		while($_GLOBAL["ro1"]=$res->fetch_assoc()){
			$i++;
			$ldate=empty($_GLOBAL["ro1"]['LDATE'])?"":date("d-m-Y", strtotime($_GLOBAL["ro1"]['LDATE']));
			
			$x_axis=$pdf->getx();
			$pdf ->vcell(20,10,$x_axis,$i,5,0);
			$pdf ->Cell(40,10,$ldate,1,0,'C'); 
			$x_axis=$pdf->getx();
			$pdf ->vcell(40,10,$x_axis,$_GLOBAL["ro1"]['HTYPE'],21,0);
			$x_axis=$pdf->getx();
			$pdf ->vcell(47,10,$x_axis,$_GLOBAL["ro1"]['FNAME'],20,0);
			$x_axis=$pdf->getx();
			$pdf ->vcell(40,10,$x_axis,'',15,1);
		}
	}else{
		$x_axis=$pdf->getx();
			$pdf ->vcell(20,10,$x_axis,'1',5,0);
			$pdf ->Cell(40,10,'',1,0,'C'); 
			$x_axis=$pdf->getx();
			$pdf ->vcell(40,10,$x_axis,'',21,0);
			$x_axis=$pdf->getx();
			$pdf ->vcell(47,10,$x_axis,'',20,0);
			$x_axis=$pdf->getx();
			$pdf ->vcell(40,10,$x_axis,'',15,1);
	
	}
	
	
	
	$pdf ->Cell(50,10,' ',0,1);
	$pdf ->SetFont('Baamini','',9);
	$pdf ->Cell(10,5,'',0,0); 
	$pdf ->Cell(145,5,'Nkw;Fwpg;gpl;Ls;s tpguq;fis rhpghh;j;Js;nsd; - tpLg;G vLg;gjw;F mDkjp toq;f ghpe;Jiu nra;fpNwd;.',0,1); 
	$pdf ->Cell(50,10,' ',0,1); 
	$pdf ->Cell(15,5,'Jiwj;jiyth; - gphpTnghWg;ghsh; ',0,0); 
	$pdf ->Cell(50,15,' ',0,1); 
    $pdf ->Cell(165,5,'',0,0); 
    $pdf ->Cell(40,5,'Gyik Kjy;th; ',0,1); 
	
	}else{
		 $pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'1. ngah;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'2. gpupT',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);

	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'3. mDkjp - tpLg;G Ntz;ba ehl;fs;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);

    $pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'4. mDkjpf;fhd - tpLg;Gf;fhd fhuzk;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'5. ntspAh; nry;y mDkjp ',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'6. ntspAh; Kfthp',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);

	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'7. ,Jtiu vLj;j tpLg;G ehl;fs;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);
    $pdf ->Cell(10,5,'',0,0); 
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(80,5,'(jw;Nghija tpLg;Gld; Nrh;j;J)',0,1);
   
   
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(5,5,'',0,1); 
    $pdf ->Cell(5,5,'',0,0); 
    $pdf ->Cell(80,5,'8. kPjpAs;s ehl;fs;',0,0);
    $pdf ->Cell(7,5,':',0,0);
	$pdf ->SetFont('RobotoCondensed','',9); 
    $pdf ->Cell(95,5,'','B',1);
	
	$pdf ->SetFont('Baamini','',9); 
    $pdf ->Cell(50,2,' ',0,1); 
    $pdf ->Cell(50,5,'Njjp: ',0,1); 

    $pdf ->Cell(50,2,' ',0,1); 
    $pdf ->Cell(135,5,'',0,0); 
    $pdf ->Cell(40,5,'tpz;zg;gjhuh; ifnahg;gk;',0,1); 

    $pdf ->Cell(50,2,' ',0,1); 
    $pdf ->Cell(135,5,'tFg;Gfs; khw;W Vw;ghL Fwpj;j tptuk;:    ',0,1); 
	$pdf ->SetFont('Baamini','',8); 
    $pdf ->Cell(50,2,' ',0,1);
    $x_axis=$pdf->getx();
    $pdf ->vcell(20,10,$x_axis,'thpirvz;',5,0);
    $pdf ->Cell(40,10,'tpLg;G ehs;',1,0,'C'); 
    $x_axis=$pdf->getx();
    $pdf ->vcell(40,10,$x_axis,'  khw;W Vw;ghL nra;Js;s   tFg;G ,jug;gzp',25,0);
    $x_axis=$pdf->getx();
    $pdf ->vcell(47,10,$x_axis,'   tFg;G-,jug;gzp elj;j    Xg;gf;nfhz;lth; ngah;',25,0);
    $x_axis=$pdf->getx();
    $pdf ->vcell(40,10,$x_axis,'Xg;gf;nfhz;lth; ifnahg;gk;',15,1);
	$pdf ->SetFont('RobotoCondensed','',8);
	
	$x_axis=$pdf->getx();
	$pdf ->vcell(20,10,$x_axis,'1',5,0);
	$pdf ->Cell(40,10,'',1,0,'C'); 
	$x_axis=$pdf->getx();
	$pdf ->vcell(40,10,$x_axis,'',21,0);
	$x_axis=$pdf->getx();
	$pdf ->vcell(47,10,$x_axis,'',20,0);
	$x_axis=$pdf->getx();
	$pdf ->vcell(40,10,$x_axis,'',15,1);
	
	$pdf ->Cell(50,10,' ',0,1);
	$pdf ->SetFont('Baamini','',9);
	$pdf ->Cell(10,5,'',0,0); 
	$pdf ->Cell(145,5,'Nkw;Fwpg;gpl;Ls;s tpguq;fis rhpghh;j;Js;nsd; - tpLg;G vLg;gjw;F mDkjp toq;f ghpe;Jiu nra;fpNwd;.',0,1); 
	$pdf ->Cell(50,10,' ',0,1); 
	$pdf ->Cell(15,5,'Jiwj;jiyth; - gphpTnghWg;ghsh; ',0,0); 
	$pdf ->Cell(50,15,' ',0,1); 
    $pdf ->Cell(165,5,'',0,0); 
    $pdf ->Cell(40,5,'Gyik Kjy;th; ',0,1); 
	
	
	}
    $pdf ->Output();
?>