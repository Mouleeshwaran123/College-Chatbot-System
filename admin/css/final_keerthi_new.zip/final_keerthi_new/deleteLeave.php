<?php 
include "config.php"; 
$sql="delete from leave_form where LID='{$_GET["lid"]}'";
$con->query($sql);
echo "<script>location.replace('staff_view_cl.php');</script>"; 
?>