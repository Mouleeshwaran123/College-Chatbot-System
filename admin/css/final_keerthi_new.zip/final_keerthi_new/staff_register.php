<!DOCTYPE html>
<?php
 include "config.php";
 session_start();
 ?>
<html lang="en">
<head>
    <?php require_once "header.php"; ?>
    <style>
      
    </style>
</head>
<body>
    <?php require_once "navbar.php"; ?>
    
    <div class="container"><br><br><br>
        <div class="row">
			<div class="col-lg-12">	
				<a href="staff_login.php" class="btn btn-sm btn-danger pull-right">Back</a>
				<h3>Faculty Registeration</h3><hr>	
					<?php
					if(isset($_POST["submit"]))
					{
						$fname=trim($_POST["fname"]);
						//$mname=trim($_POST["mname"]);
						//$lname=trim($_POST["lname"]);
						$staffid=trim($_POST["staffid"]);
						$spass=trim($_POST["spass"]);
						$desti=trim($_POST["desti"]);
						$depart=trim($_POST["depart"]);
						$gender=trim($_POST["gender"]);
						$dob=trim($_POST["dob"]);
						$email=trim($_POST["email"]);
						$contact=trim($_POST["contact"]);
						$address=trim($_POST["address"]);
						
						 $sql="insert into staff_details (FNAME, STAFFID, SPASS, DESTI, DEPART, GENDER, DOB, EMAIL, CONTACT, ADDRESS) values('$fname','$staffid','$spass','$desti','$depart','$gender','$dob','$email','$contact','$address')";
						if($con->query($sql))
						{
							echo "<div class='alert alert-success'>Registration Success</div>";
						}else{
							echo "<div class='alert alert-danger'>Registration Failed</div>";
						}
					}
				
				?>
					<form action="<?php echo $_SERVER["REQUEST_URI"];?>" method="post" autocomplete="off">
					
					<div class="col-lg-5">	
						<div class=" from-group">
							<label> First Name </label>
							<input type="text" name="fname" class="form-control text">
						</div>
					<!--	<div class="from-group">
							<label>Middle Name</label>
							<input type="text" class="form-control" name="mname">
						</div>
						<div class="from-group">
							<label>Last Name</label>
							<input type="text" class="form-control" name="lname">
						</div>  -->
						<div class="from-group">
							<label>Faculty ID</label>
							<input type="text" class="form-control" name="staffid">
						</div>
						<div class="from-group">
							<label>Password</label>
							<input type="password" class="form-control" name="spass">
						</div>
						<div class="from-group">
							<label>Designation</label>
							<select type="text"  class="form-control" name="desti">
							<option value="">Select</option> 
								<?php
								$sql = "select * from designation";
									$res=$con->query($sql);
									if($res->num_rows>0)
									{
										while($row=$res->fetch_assoc())
										{
											echo"<option value='{$row["DESNAME"]}'>{$row["DESNAME"]}</option>";
										}
										
									}
								?>
							</select>
						</div>
						<div class=" from-group">
							<label>Department</label>
							<select type="text"  class="form-control" name="depart">
							<option value="">Select</option>
								<?php
								$sql = "select * from course";
									$re=$con->query($sql);
									if($re->num_rows>0)
									{
										while($ro=$re->fetch_assoc())
										{
											echo"<option value='{$ro["CNAME"]}'>{$ro["CNAME"]}</option>";
										}
										
									}
								?>
							</select>
						</div>
					</div>
					<div class="col-md-offset-1 col-lg-5">	
						
						<div class="from-group">
							<label>Gender</label>
							<select type="text"  class="form-control" name="gender">
							<option value="">Select</option>
							<option value="Female">Female</option>
							<option value="Male">Male</option>							
							</select>
						</div>
						<div class="from-group">
							<label>DOB</label>
							<input type="date" class="form-control datepicker" name="dob">
						</div>
						<div class="from-group">
							<label>Email ID</label>
							<input type="text" class="form-control" name="email">
						</div>
						<div class="from-group">
							<label>Contact Number</label>
							<input type="text" class="form-control" name="contact">
						</div>
						<div class="from-group">
							<label>Address</label>
							<input type="text" class="form-control" name="address">
						</div>
					</div>
					
					<div class="col-lg-12">	
						<div class="from-group"><br><br>
							<button type="submit" class="btn btn-success " name="submit"> Register</button>
						</div>						
					</div>						
					</form>
				
				</div>
				
			</div>
        </div>
    </div>

    <?php require_once "footer.php"; ?>
</body>
</html>