$(function() {
    //Numeric Only
    $('.num').keypress(function(evt){
        return (/^[0-9]*\.?[0-9]*$/).test($(this).val()+evt.key);
    });
 
        /* Enter Text and White Space Only */
        $(".text").keypress(function(event){
            var inputVal=event.which;
            /*if (inputVal === 46 && this.value.split('.').length === 2) {
                return false;
            }*/

            if(!(inputVal>=65 && inputVal <=90)&!(inputVal>=97 && inputVal <=122)&(inputVal!=32 && inputVal!=0&&inputVal!=46&& inputVal!=64))
            {
                event.preventDefault();
            }
        });

    });